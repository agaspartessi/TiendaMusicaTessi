import bajo from './bajo.jpg';
import guitarra from './guitarra.jpg';
import bateria from './bateria.jpg';

export const products = [
    {
        id: 1,
        name: 'Guitarra Fender',
        price: '100',
        image: guitarra,
        stock:'30',
        description:'Esta es una guitarra cara',
        category:'guitarra'

    },
    {
        id: 2,
        name: 'Bateria MAPPET',
        price: '200',
        image: bateria,
        stock:'20',
        description:'Esta es una bateria cara',
        category:'bateria'

    },
    {
        id: 3,
        name: 'Bajo FAIM',
        price: '300',
        image: bajo,
        stock:'10',
        description:'Esta es un bajo caro',
        category:'bajo'

    },

];

export const traerProductos = (cat) => {
    return new Promise((resolve, reject) => {
        const productosFiltrados = products.filter(
            (prod) => prod.category === cat
        );
        setTimeout(() => {
            if (cat === undefined) {
                resolve(products);
            } else {
                resolve(productosFiltrados);
            }
        }, 1000);
    });
};

/*
export const traerProducto = (item) => {
    return new Promise((resolve, reject) => {
        const itemFiltrados = products.filter(
            (prod) => prod.id === item
        );
        setTimeout(() => {
            if (item === undefined) {
                resolve(item);
            } else {
                resolve(itemFiltrados);
            }
        }, 1000);
    });
};*/
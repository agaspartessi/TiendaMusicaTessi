import React from 'react';
import { useEffect, useState } from 'react';
import { traerProductos } from '../productos.js';
import ItemList from './ItemList';
import { useParams } from 'react-router-dom';


const ItemListContainer = () => {
    const [products, setProducts] = useState([]);

    const { categoryId } = useParams();

    useEffect(() => {
        traerProductos(categoryId)
            .then((res) => {
                setProducts(res);
            })
            .catch((error) => console.log(error));
    }, [categoryId]);

    return (
        <div>
            <ItemList products={products} />
        </div>
    );
};

export default ItemListContainer;
/*
const ItemListContainer = () => {
    const [items, setItems] = useState([]);
    const {cat} = useParams();

    useEffect (() => {
        setTimeout (() => {
        const data = new Promise((resolve,reject) => {
            const productosFiltrados = prod.filter((prod) => prod.category === cat)
            if (cat === undefined){
                resolve(prod);
            } else {
                resolve(productosFiltrados);
            }
            
        });
        data.then((data) => {
            setItems(data);
        });
        data.catch((err) => {
            console.log(err);
        });
}, 2000);
}, []);

    return (<div>  
        <ItemList items={items} />
    </div>
    );
};

export default ItemListContainer ;
*/